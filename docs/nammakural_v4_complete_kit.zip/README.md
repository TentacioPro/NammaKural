# NammaKural (நம்ம குரல்) — Complete v4.1 Rulebook & Build+Review Skills Pack

Drop `skills/*` into `.agent/skills/` (Antigravity, Cursor, or Claude Code) and open `rulebook/nammakural_dual_track_rulebook_v4_1.html` offline in any browser.

## Included Custom Skills (8 SKILL.md Files)

### Build Skills (Updated for 3-Tier Auto-Detect Engine + Judge Alerts)
1. `skills/tamil-voice-agent-architect/SKILL.md` — 3-Tier Engine (Offline CPU -> Cloud API -> Local Gemma-4 E2B), `display_text` vs `tts_text` Tamil Unicode split, Sarvam `saaras:v4` codemix, `Code > LLM` FSM, Bharat State Packs.
2. `skills/voice-agent-a11y-ui/SKILL.md` — Universal WCAG 2.2 AA+ UI, zero Wispr Flow DNA, Engine Mode Pill (`Offline FSM` / `Local Gemma-4` / `Cloud API`), 140x140px Tactile Orb, 56px Dock, collapsed mobile drawer, Clarity Popup sync.
3. `skills/civic-ai-pitch-deck/SKILL.md` — Text-first PDF Pitch Deck covering the 4 mandatory hackathon prompts + 3-tier engine resilience story.
4. `skills/youtube-video-editor/SKILL.md` — <= 3:00 YouTube Demo beat sheet (Remotion / HeyGen HyperFrames).
5. `skills/nammakural-tdd-evals/SKILL.md` — 6-perspective TDD, Playwright A11y QA, and behavioral regression gate.

### Dedicated Review & Validation Skills (Audit Work Produced by Build Skills)
6. `skills/review-voice-agent-code/SKILL.md` — Read-only voice-agent code audit (zero-key Docker safety, GPU-free default compose, PII firewall, TTS guard, `Code > LLM` enforcement).
7. `skills/review-pitch-deck/SKILL.md` — Read-only judge-lens pitch deck audit (text-readability without visuals, 4 mandatory prompts, dependency/fallback proof).
8. `skills/review-demo-video/SKILL.md` — Read-only demo video audit (<= 3:00 cap, -14 LUFS loudness, burned Tamil/EN captions, mobile-first proof, HyperFrames/Remotion lint).

## Recommended Community Review Skills to Install Alongside These
```bash
# 1. UI Technical Audit (/impeccable audit) + Design Taste (/impeccable critique)
npx impeccable install

# 2. Code Review Subagent + Verification-Before-Completion (Antigravity native)
agy plugin install https://github.com/obra/superpowers

# 3. PR Review Toolkit (error handling, tests, type design)
npx skills add anthropics/claude-plugins-official --skill pr-review-toolkit

# 4. HeyGen HyperFrames (includes lint/check/diff + motion-doctrine)
npx skills add heygen-com/hyperframes

# 5. Remotion Official Skills
npx skills add remotion-dev/skills
```
